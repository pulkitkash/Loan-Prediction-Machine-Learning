# LoanSight — Loan Eligibility Predictor

A Flask web app that predicts loan approval using an XGBoost ML model.

## Quick Start

### 1. Install dependencies
```bash
pip install -r requirements.txt
```

> **Note:** If `xgboost` fails to install, the app will still run using a
> built-in rule-based fallback. To use the real ML model, install xgboost:
> `pip install xgboost`

### 2. Run the app
```bash
python app.py
```

Then open: **http://localhost:5000**

### 3. Register & Login
- Go to `/register` to create an account
- Use any username, email, and password (min 6 chars)

---

## Features
- XGBoost ML model with 32-feature prediction (DTI, credit score, employment, etc.)
- Rule-based fallback if model can't load
- Full prediction history with CSV export
- EMI calculator for approved loans
- Admin panel (set `is_admin=1` in DB for a user)

## Model Features (32 total)
The model uses: age, credit score, employment years, debt-to-income ratio,
existing loans, loan term, interest rate, date features, income/amount logs,
education level, and one-hot encoded: gender, marital status, employment type,
loan purpose, home ownership.

## Files
- `app.py` — Main Flask application (fixed)
- `model.pkl` — Pre-trained XGBoost model
- `generate_model.py` — Script to regenerate a compatible model.pkl
- `templates/` — Jinja2 HTML templates
- `instance/loan_app.db` — SQLite database (auto-created on first run)

## Fixes Applied
1. XGBoost compatibility stub — app loads model.pkl even without xgboost installed
2. Correct 32-feature order matching the model's trained feature names
3. `instance/` directory auto-created before DB init (no FileNotFoundError)
4. `history.html` bug: `p.employment` → `p.employment_type`
5. Removed broken `{templates,static/` directory from archive
6. Robust form parsing: empty/None fields handled with safe defaults
7. Model load attempted only once (cached), with two-loader fallback
8. `run_prediction` always falls back gracefully on any exception
